<?php
if (class_exists("SoapClient")) {
    echo "SOAP is installed and enabled!";
} else {
    echo "SOAP is not installed or enabled.";
}
?>

